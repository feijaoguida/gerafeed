# 112 Product Offer Management

## Objetivo
Gerenciar ProductOffer.

## Escopo
Adicionar novo affiliateUrl, importar, editar seller/trackingLabel, status ACTIVE/PAUSED/ARCHIVED e oferta preferencial quando aplicável.

## Definition of Done
- [ ] CRUD.
- [ ] Provider validation/import.
- [ ] Status.
- [ ] Tenant isolation.
- [ ] TypeScript/Lint/Tests PASS.

## Validation
Executar testes automatizados e validação manual aplicável.

## Evidence
Registrar arquivos alterados, comandos executados, resultados e limitações.
