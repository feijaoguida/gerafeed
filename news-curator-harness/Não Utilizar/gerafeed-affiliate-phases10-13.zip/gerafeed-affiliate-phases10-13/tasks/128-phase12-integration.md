# 128 Phase12 Integration

## Objetivo
Validar motor de conteúdo Affiliate.

## Escopo
Cenários review, comparison, best products e buying guide. Garantir dados estruturados, nenhum produto inventado e nenhum affiliateUrl no documento.

## Definition of Done
- [ ] Cenários PASS.
- [ ] Legacy news intacto.
- [ ] TypeScript/Lint/Tests/Build PASS.

## Validation
Executar testes automatizados e validação manual aplicável.

## Evidence
Registrar arquivos alterados, comandos executados, resultados e limitações.
