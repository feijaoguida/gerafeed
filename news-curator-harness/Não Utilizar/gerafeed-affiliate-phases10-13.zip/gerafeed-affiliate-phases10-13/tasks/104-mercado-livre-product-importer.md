# 104 Mercado Livre Product Importer

## Objetivo
Importar metadados a partir do affiliateUrl resolvido.

## Escopo
Pipeline resolver → externalProductId/canonical URL → fonte oficial/provider → fallback isolado de metadados públicos estruturados → NormalizedProductImport COMPLETE/PARTIAL/FAILED. Nunca acessar Portal autenticado e nunca inventar dados.

## Definition of Done
- [ ] COMPLETE/PARTIAL/FAILED.
- [ ] metadataSource/fetchedAt/warnings.
- [ ] Preço tratado como snapshot.
- [ ] Fixtures/testes.
- [ ] TypeScript/Lint/Tests PASS.

## Validation
Executar testes automatizados e validação manual aplicável.

## Evidence
Registrar arquivos alterados, comandos executados, resultados e limitações.
