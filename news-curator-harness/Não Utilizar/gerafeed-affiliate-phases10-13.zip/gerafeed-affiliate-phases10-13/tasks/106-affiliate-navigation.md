# 106 Affiliate Navigation

## Objetivo
Adicionar módulo Affiliate ao menu.

## Escopo
Menu: Dashboard, Produtos, Ofertas, Conteúdo. Sem AFFILIATE_MODULE ocultar ou upsell, mas APIs permanecem protegidas.

## Definition of Done
- [ ] Sidebar.
- [ ] Entitlement UI.
- [ ] Protected routes.
- [ ] Responsive.
- [ ] TypeScript/Lint PASS.

## Validation
Executar testes automatizados e validação manual aplicável.

## Evidence
Registrar arquivos alterados, comandos executados, resultados e limitações.
