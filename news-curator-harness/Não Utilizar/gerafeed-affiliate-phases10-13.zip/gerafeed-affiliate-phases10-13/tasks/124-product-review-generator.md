# 124 Product Review Generator

## Objetivo
Gerar reviews com dados estruturados.

## Escopo
Input: Product/Offer/specs/PromptTemplate/keyword. Output: canonical document + SEO. Não inventar teste físico, specs ou preço.

## Definition of Done
- [ ] Structured generation.
- [ ] Canonical blocks/SEO.
- [ ] Guard tests.
- [ ] TypeScript/Lint PASS.

## Validation
Executar testes automatizados e validação manual aplicável.

## Evidence
Registrar arquivos alterados, comandos executados, resultados e limitações.
