# 130 Publisher Adapter

## Objetivo
Desacoplar publicação do WordPress.

## Escopo
Criar PublisherAdapter com testConnection/createDraft/publish/update. Implementar WordPressPublisherAdapter usando serviços existentes sem quebrar notícias.

## Definition of Done
- [ ] Interface/factory.
- [ ] WordPress adapter.
- [ ] Legacy publish PASS.
- [ ] TypeScript/Lint/Tests PASS.

## Validation
Executar testes automatizados e validação manual aplicável.

## Evidence
Registrar arquivos alterados, comandos executados, resultados e limitações.
