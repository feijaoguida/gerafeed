# 122 Article Product Relations

## Objetivo
Relacionar artigos a produtos/ofertas.

## Escopo
ArticleProduct com position, badge, score, recommendation e offerId opcional. Review exige 1 produto; Comparison >=2; mesma Workspace.

## Definition of Done
- [ ] Schema/constraints.
- [ ] Ordering/validation.
- [ ] Tenant tests.
- [ ] TypeScript/Lint PASS.

## Validation
Executar testes automatizados e validação manual aplicável.

## Evidence
Registrar arquivos alterados, comandos executados, resultados e limitações.
