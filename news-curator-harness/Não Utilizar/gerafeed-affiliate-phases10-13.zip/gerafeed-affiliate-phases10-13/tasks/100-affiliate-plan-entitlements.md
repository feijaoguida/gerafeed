# 100 Affiliate Plan Entitlements

## Objetivo
Adicionar Affiliate às Features do Backoffice.

## Escopo
Features: AFFILIATE_MODULE (BOOLEAN), AFFILIATE_ANALYTICS (BOOLEAN), AFFILIATE_MAX_PRODUCTS (QUANTITY), AFFILIATE_MAX_PROGRAMS (QUANTITY). Reutilizar Billing/Feature service existente. APIs Affiliate devem validar server-side. Não implementar catálogo ainda.

## Definition of Done
- [ ] Features seedadas.
- [ ] Backoffice consegue atribuir.
- [ ] Workspace permitido passa.
- [ ] Workspace sem feature é bloqueado.
- [ ] Limite numérico funciona.
- [ ] TypeScript/Lint/Tests/Build PASS.

## Validation
Executar testes automatizados e validação manual aplicável.

## Evidence
Registrar arquivos alterados, comandos executados, resultados e limitações.
