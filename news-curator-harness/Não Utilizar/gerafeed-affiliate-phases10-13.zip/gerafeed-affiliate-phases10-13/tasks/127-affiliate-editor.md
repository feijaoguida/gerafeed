# 127 Affiliate Editor

## Objetivo
Criar editor/revisão comercial.

## Escopo
Mostrar tipo, prompt, keyword, produtos/ofertas, ordem, badges, score, recommendation, preview canônico, SEO e disclosure. Human approval obrigatória.

## Definition of Done
- [ ] Create/edit/select/reorder.
- [ ] Preview/SEO.
- [ ] Human approval.
- [ ] TypeScript/Lint PASS.

## Validation
Executar testes automatizados e validação manual aplicável.

## Evidence
Registrar arquivos alterados, comandos executados, resultados e limitações.
