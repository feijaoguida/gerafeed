# 134 Affiliate Click Tracking

## Objetivo
Registrar cliques sem redirect obrigatório.

## Escopo
Href direto para affiliateUrl. sendBeacon/fetch keepalive em paralelo. Token opaco/assinado. Não aceitar workspaceId arbitrário. Não armazenar IP bruto sem requisito.

## Definition of Done
- [ ] Model/token/endpoint/beacon.
- [ ] Direct href.
- [ ] Failure non-blocking.
- [ ] Abuse tests.
- [ ] TypeScript/Lint PASS.

## Validation
Executar testes automatizados e validação manual aplicável.

## Evidence
Registrar arquivos alterados, comandos executados, resultados e limitações.
