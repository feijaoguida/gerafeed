# 126 Best Products And Buying Guide

## Objetivo
Implementar Best Products e Buying Guide.

## Escopo
BEST_PRODUCTS usa apenas produtos selecionados. BUYING_GUIDE foca critérios de compra e pode referenciar catálogo. IA não adiciona produtos não selecionados.

## Definition of Done
- [ ] Generators/prompts.
- [ ] Canonical blocks/SEO.
- [ ] No hallucinated products.
- [ ] TypeScript/Lint/Tests PASS.

## Validation
Executar testes automatizados e validação manual aplicável.

## Evidence
Registrar arquivos alterados, comandos executados, resultados e limitações.
