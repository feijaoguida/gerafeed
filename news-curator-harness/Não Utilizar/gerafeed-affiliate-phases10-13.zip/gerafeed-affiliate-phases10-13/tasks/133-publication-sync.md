# 133 Publication Sync

## Objetivo
Marcar publicação desatualizada quando oferta muda.

## Escopo
Usar renderedContentHash, needsRepublish e lastPublishedAt. Mudança relevante em ProductOffer marca publicações dependentes. Republish manual no MVP.

## Definition of Done
- [ ] Dependency lookup.
- [ ] needsRepublish.
- [ ] UI indicator/manual republish.
- [ ] Tests.
- [ ] TypeScript/Lint PASS.

## Validation
Executar testes automatizados e validação manual aplicável.

## Evidence
Registrar arquivos alterados, comandos executados, resultados e limitações.
