# 105 Affiliate Import Preview And Confirm

## Objetivo
Criar UX de colar link, buscar, revisar e confirmar.

## Escopo
Tela Afiliados > Produtos > Importar Mercado Livre. Preview editável com imagem, nome, marca, seller, specs, preço snapshot e warnings. Só persistir em transaction após confirmação. Dedupe por externalProductId e URLs.

## Definition of Done
- [ ] Campo affiliateUrl.
- [ ] Loading/erros.
- [ ] Preview.
- [ ] PARTIAL manual.
- [ ] Confirm transaction.
- [ ] Dedupe.
- [ ] Entitlement/tenant isolation.
- [ ] TypeScript/Lint/Tests PASS.

## Validation
Executar testes automatizados e validação manual aplicável.

## Evidence
Registrar arquivos alterados, comandos executados, resultados e limitações.
