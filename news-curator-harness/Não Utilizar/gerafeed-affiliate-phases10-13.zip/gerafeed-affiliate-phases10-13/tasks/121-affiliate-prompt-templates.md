# 121 Affiliate Prompt Templates

## Objetivo
Criar prompts por tipo Affiliate.

## Escopo
PromptTemplate com scope/type/name/systemPrompt/userPromptTemplate/version/active e override Workspace. Seeds para Review, Comparison, Best Products, Buying Guide e Problem Solution.

## Definition of Done
- [ ] Defaults/override.
- [ ] API/UI/preview.
- [ ] Version/validation.
- [ ] TypeScript/Lint/Tests PASS.

## Validation
Executar testes automatizados e validação manual aplicável.

## Evidence
Registrar arquivos alterados, comandos executados, resultados e limitações.
