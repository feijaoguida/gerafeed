# 102 Affiliate Product Schema

## Objetivo
Criar ProductCategory, Product e ProductOffer.

## Escopo
ProductOffer contém affiliateUrl obrigatório e metadata de importação: externalProductId, originalUrl/resolvedUrl, metadataSource e metadataLastFetchedAt. Adicionar índices úteis e tenant isolation.

## Definition of Done
- [ ] Prisma/migration.
- [ ] Constraints/índices.
- [ ] Tenant tests.
- [ ] TypeScript/Lint/Tests PASS.

## Validation
Executar testes automatizados e validação manual aplicável.

## Evidence
Registrar arquivos alterados, comandos executados, resultados e limitações.
