# 123 Canonical Content Document

## Objetivo
Criar documento canônico independente do WordPress.

## Escopo
Blocos versionados: RICH_TEXT, HEADING, PRODUCT_CARD, PRODUCT_COMPARISON, PROS_CONS, CTA, AFFILIATE_DISCLOSURE, IMAGE. Referenciar IDs, nunca affiliateUrl.

## Definition of Done
- [ ] Schema/validation/serialization.
- [ ] Legacy content intacto.
- [ ] Tests.
- [ ] TypeScript/Lint PASS.

## Validation
Executar testes automatizados e validação manual aplicável.

## Evidence
Registrar arquivos alterados, comandos executados, resultados e limitações.
