# 135 Affiliate Dashboard

## Objetivo
Criar dashboard Affiliate.

## Escopo
Cards/rankings para produtos, ofertas, artigos e cliques, top produtos/artigos/sites/componentes. AFFILIATE_ANALYTICS obrigatório. Não exibir vendas/comissão/conversão como fatos.

## Definition of Done
- [ ] Cards/rankings/date filters.
- [ ] Entitlement/tenant isolation.
- [ ] Responsive.
- [ ] TypeScript/Lint PASS.

## Validation
Executar testes automatizados e validação manual aplicável.

## Evidence
Registrar arquivos alterados, comandos executados, resultados e limitações.
