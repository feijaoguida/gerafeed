# 103 Secure Affiliate Link Resolver

## Objetivo
Resolver affiliateUrl sem abrir vetor SSRF.

## Escopo
Implementar resolver server-side com allowlist por provider, bloqueio localhost/private/link-local, DNS/IP validation, redirect validation, max redirects, timeout, response limits e sem forward de cookies/Authorization. Retornar erros tipados.

## Definition of Done
- [ ] Resolver seguro.
- [ ] Redirect chain validada.
- [ ] Localhost/private IP bloqueados.
- [ ] Host inválido bloqueado.
- [ ] Timeout.
- [ ] TypeScript/Lint/Tests PASS.

## Validation
Executar testes automatizados e validação manual aplicável.

## Evidence
Registrar arquivos alterados, comandos executados, resultados e limitações.
