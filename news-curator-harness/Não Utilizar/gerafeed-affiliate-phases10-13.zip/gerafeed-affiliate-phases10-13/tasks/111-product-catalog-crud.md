# 111 Product Catalog Crud

## Objetivo
Gerenciar Product.

## Escopo
Listar, buscar, filtrar, editar, ativar/arquivar, specs, pros/cons, imagem e categoria. Aplicar AFFILIATE_MAX_PRODUCTS.

## Definition of Done
- [ ] CRUD/filtros.
- [ ] Plan limit.
- [ ] Tenant isolation.
- [ ] TypeScript/Lint/Tests PASS.

## Validation
Executar testes automatizados e validação manual aplicável.

## Evidence
Registrar arquivos alterados, comandos executados, resultados e limitações.
