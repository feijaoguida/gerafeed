# 114 Product Catalog Ui

## Objetivo
Criar UI completa do catálogo.

## Escopo
Listagem com nome, imagem, categoria, programa, oferta ativa, atualização e status. Filtros. Detalhe com abas Produto, Specs, Ofertas e Conteúdos relacionados.

## Definition of Done
- [ ] Listagem/filtros.
- [ ] Detalhe/abas.
- [ ] Responsive/loading/error.
- [ ] TypeScript/Lint PASS.

## Validation
Executar testes automatizados e validação manual aplicável.

## Evidence
Registrar arquivos alterados, comandos executados, resultados e limitações.
