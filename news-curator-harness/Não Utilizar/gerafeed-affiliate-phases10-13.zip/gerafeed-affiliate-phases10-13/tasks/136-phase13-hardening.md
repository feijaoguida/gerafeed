# 136 Phase13 Hardening

## Objetivo
Auditar toda a plataforma Affiliate.

## Escopo
Auditar tenant, entitlement, SSRF, dedupe, marketplace import, conteúdo, PublisherAdapter, sponsored/disclosure, tracking seguro e distinção clique != venda.

## Definition of Done
- [ ] Security/tenant/entitlement audit.
- [ ] Resolver audit.
- [ ] No Portal scraping.
- [ ] No hallucinated product facts.
- [ ] No affiliateUrl in canonical doc.
- [ ] Publisher/Tracking audits.
- [ ] TypeScript/Lint/Tests/Build PASS.

## Validation
Executar testes automatizados e validação manual aplicável.

## Evidence
Registrar arquivos alterados, comandos executados, resultados e limitações.
