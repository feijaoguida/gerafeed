# 101 Affiliate Program And Provider

## Objetivo
Criar AffiliateProgram e contrato AffiliateProvider.

## Escopo
Seed MERCADO_LIVRE. Criar interface/factory com capabilities, validateAffiliateUrl, resolveAffiliateUrl e fetchProductMetadata. Mercado Livre: automaticAffiliateLinkGeneration=false, affiliateLinkImport=true, productMetadataImport=true, supportsTrackingLabel=true. Não criar workflow de compliance.

## Definition of Done
- [ ] Model/seed.
- [ ] Interface/factory.
- [ ] MercadoLivreAffiliateProvider.
- [ ] Testes de capabilities.
- [ ] TypeScript/Lint/Tests PASS.

## Validation
Executar testes automatizados e validação manual aplicável.

## Evidence
Registrar arquivos alterados, comandos executados, resultados e limitações.
