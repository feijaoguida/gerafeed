# 110 Product Category

## Objetivo
Criar taxonomia própria do catálogo.

## Escopo
ProductCategory workspace-scoped com parentId opcional, name, slug e active. Não usar WordPressCategory.

## Definition of Done
- [ ] CRUD.
- [ ] Parent/child.
- [ ] Constraints.
- [ ] Tenant isolation.
- [ ] TypeScript/Lint/Tests PASS.

## Validation
Executar testes automatizados e validação manual aplicável.

## Evidence
Registrar arquivos alterados, comandos executados, resultados e limitações.
