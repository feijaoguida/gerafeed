# 120 Affiliate Article Types

## Objetivo
Adicionar tipos comerciais ao Article.

## Escopo
PRODUCT_REVIEW, COMPARISON, BEST_PRODUCTS, BUYING_GUIDE, PROBLEM_SOLUTION, DEALS, SEASONAL. Campo nullable/retrocompatível.

## Definition of Done
- [ ] Schema/migration.
- [ ] Validation/filtros.
- [ ] Legacy intacto.
- [ ] TypeScript/Lint/Tests PASS.

## Validation
Executar testes automatizados e validação manual aplicável.

## Evidence
Registrar arquivos alterados, comandos executados, resultados e limitações.
