# 131 Wordpress Affiliate Renderer

## Objetivo
Renderizar documento canônico para WordPress.

## Escopo
Renderizar text, headings, product card, comparison, pros/cons, CTA e disclosure. Resolver ProductOffer no publish e sanitizar HTML.

## Definition of Done
- [ ] Renderer/cards/comparison/CTA.
- [ ] Offer resolution.
- [ ] Sanitization/tests.
- [ ] TypeScript/Lint PASS.

## Validation
Executar testes automatizados e validação manual aplicável.

## Evidence
Registrar arquivos alterados, comandos executados, resultados e limitações.
