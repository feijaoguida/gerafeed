# 113 Product Deduplication And Refresh

## Objetivo
Implementar dedupe e refresh manual.

## Escopo
Botão Atualizar dados do Mercado Livre. Sem cron. externalProductId é prioridade. Definir merge policy para não sobrescrever edição editorial sem regra explícita.

## Definition of Done
- [ ] Refresh.
- [ ] Dedupe.
- [ ] Merge policy.
- [ ] metadataLastFetchedAt.
- [ ] TypeScript/Lint/Tests PASS.

## Validation
Executar testes automatizados e validação manual aplicável.

## Evidence
Registrar arquivos alterados, comandos executados, resultados e limitações.
