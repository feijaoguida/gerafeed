# 132 Affiliate Disclosure And Link Compliance

## Objetivo
Padronizar disclosure e atributos de link.

## Escopo
Links usam rel=sponsored nofollow. Disclosure default configurável no Workspace. Canal Mercado Livre é assumido validado externamente.

## Definition of Done
- [ ] sponsored/nofollow.
- [ ] disclosure/default/override.
- [ ] Tests.
- [ ] TypeScript/Lint PASS.

## Validation
Executar testes automatizados e validação manual aplicável.

## Evidence
Registrar arquivos alterados, comandos executados, resultados e limitações.
