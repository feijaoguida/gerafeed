# Architectural Decisions

## Histórico

As decisões anteriores (ADR-010 em diante) permanecem válidas, salvo quando explicitamente substituídas por uma decisão posterior.

## ADR-022. WordPressSite como entidade própria
Status: Accepted

Um Workspace pode possuir múltiplos sites WordPress. Não representar isso somente por JSON em `Configuration`.

`WordPressSite` será entidade de domínio com credenciais criptografadas.

Motivo:
- múltiplos destinos;
- estado independente;
- categorias por destino;
- associação de feeds;
- histórico e auditoria.

## ADR-023. Source global no Workspace
Status: Accepted

Feed/RSS continua sendo uma entidade do Workspace e não uma propriedade exclusiva de um WordPressSite.

Um mesmo Feed pode alimentar vários sites.

## ADR-024. Relação N:N Feed ↔ WordPress
Status: Accepted

Criar uma entidade de associação, como `WordPressSiteSource`.

Ela armazena o vínculo e permite override de prompt específico do destino.

Motivo: o mesmo feed pode ser adaptado para diferentes portais.

## ADR-025. Hierarquia de Prompt
Status: Accepted

A resolução final usa:

```text
Feed ↔ WordPress override
→ Feed default
→ WordPress default
→ Workspace default
```

A resolução fica em serviço/função central.

## ADR-026. Article pertence a um destino editorial
Status: Accepted

Quando um artigo tem destino definido, `Article.wordpressSiteId` registra o WordPress para o qual foi preparado.

Motivos:
- filtro;
- prompt correto;
- publicação;
- auditoria.

## ADR-027. Backoffice como segunda área da mesma aplicação
Status: Accepted

Backoffice utiliza o mesmo Next.js e banco, mas possui layout, rotas e autorização próprios.

Não criar segundo aplicativo para o MVP.

## ADR-028. SuperAdmin global
Status: Accepted

`User.isSuperAdmin` autoriza Backoffice.

`WorkspaceUser.role` não concede acesso ao Backoffice.

## ADR-029. Empresa é Workspace
Status: Accepted

No Backoffice, o conceito apresentado ao operador é “Empresa”, mas o registro de domínio continua sendo `Workspace`.

Não criar `Company` duplicada sem necessidade.

## ADR-030. Feature e PlanFeature
Status: Accepted

Planos são configurados através de Features associadas por `PlanFeature`, permitindo `enabled` e `limit` quando aplicável.

O cálculo real de uso/limite deve permanecer no BillingService.

## ADR-031. Seed SuperAdmin por environment
Status: Accepted

Seed utiliza `SUPERADMIN_EMAIL` e `SUPERADMIN_PASSWORD`.

Não hardcodar credenciais.

## ADR-032. Secrets nunca são expostos ao SuperAdmin
Status: Accepted

Mesmo SuperAdmin não recebe Application Password/API Keys descriptografadas. O Backoffice permite substituir secrets, não visualizá-los.

# Affiliate Platform Decisions

## ADR-033. Mercado Livre e canal são pré-condições externas
Status: Accepted
O MVP assume que conta afiliada e canal/site já estão configurados/validados externamente. GeraFeed não gerencia essa aprovação.

## ADR-034. affiliateUrl é a entrada principal
Status: Accepted
Usuário faz curadoria no Mercado Livre, gera o link e cola no GeraFeed. URL original é derivada quando possível.

## ADR-035. Import Preview antes de persistir
Status: Accepted
Importação gera preview. Product/ProductOffer são persistidos apenas após confirmação.

## ADR-036. Safe Affiliate Link Resolver
Status: Accepted
Toda resolução usa proteção SSRF, allowlist, validação de redirects, timeout e limites.

## ADR-037. Best-effort metadata import
Status: Accepted
Importador retorna COMPLETE/PARTIAL/FAILED e nunca inventa dados ausentes.

## ADR-038. externalProductId como identidade externa preferencial
Status: Accepted
Deduplicação prioriza workspace + programa + externalProductId.

## ADR-039. Product separado de ProductOffer
Status: Accepted
Product é item conceitual. ProductOffer é oferta concreta e contém affiliateUrl.

## ADR-040. AffiliateProvider
Status: Accepted
Mercado Livre é o primeiro provider; provider encapsula validação, resolução e metadados.

## ADR-041. Affiliate por entitlement
Status: Accepted
Acesso usa Feature/PlanFeature, não nome do plano.

## ADR-042. Conteúdo canônico Affiliate
Status: Accepted
Conteúdo comercial novo é estruturado e independente do WordPress.

## ADR-043. PublisherAdapter
Status: Accepted
WordPress é primeiro destino; arquitetura permite Blogger/Custom.

## ADR-044. Link não pertence ao HTML canônico
Status: Accepted
Renderer resolve ProductOffer na publicação.

## ADR-045. Clique não é venda
Status: Accepted
AffiliateClick mede clique; venda/comissão dependem de fonte externa confiável.

# Phase 17+. Product Intelligence & Publishing Decisions

## ADR-046. Source data separado de editorial
Status: Accepted
Marketplace metadata não sobrescreve silenciosamente campos editoriais.

## ADR-047. Marketplace Category não é ProductCategory
Status: Accepted
Categoria externa é metadata/sugestão; taxonomia interna continua decisão do Workspace.

## ADR-048. ProductReviewSample
Status: Accepted
Até 5 amostras públicas, sem PII desnecessária, usadas como grounding qualitativo.

## ADR-049. ProductReferenceSource
Status: Accepted
URLs externas podem ser resumidas por IA via Safe Fetch; não copiar artigo integral.

## ADR-050. Dashboard informativo
Status: Accepted
Operação de publicação migra para Central de Publicação.

## ADR-051. Central de Publicação com dois fluxos
Status: Accepted
RSS/Notícias e Conteúdo Affiliate.

## ADR-052. RSS pode usar Affiliate Placements
Status: Accepted
IA pode sugerir catálogo real, usuário aprova, renderer resolve link no publish.

## ADR-053. Regras de seleção pertencem ao Template
Status: Accepted
selectionMode/min/max/category são source of truth compartilhada por UI/backend.

## ADR-054. Prompts Affiliate globais
Status: Accepted
Substitui override Affiliate por Workspace. Apenas SuperAdmin administra no Backoffice.

## ADR-055. Usuário seleciona template, não edita prompt
Status: Accepted
Área funcional fornece inputs e seleciona tipo/template.

## ADR-056. Prompt Affiliate versionado
Status: Accepted
Artigo guarda template ID/versão para auditoria.
