# Task 161. Publishing Center Shell

Criar `Publicar Posts` com dois cards: Notícia/RSS e Conteúdo de Afiliado. Respeitar tenant, entitlements e design system.

## Definition of Done
- [ ] menu/route
- [ ] two flows
- [ ] permissions
- [ ] responsive
- [ ] TypeScript/Lint PASS
