# Task 164. Article Affiliate Placements

Criar ArticleAffiliatePlacement com workspaceId, articleId, productId, offerId?, placementType, paragraphIndex?, position, label?. Tipos: PRODUCT_CARD, INLINE_CTA, AFTER_PARAGRAPH, TOP_RECOMMENDATION. Renderer resolve oferta.

## Definition of Done
- [ ] schema/migration
- [ ] service/validation
- [ ] renderer
- [ ] tests/TypeScript/Lint PASS
