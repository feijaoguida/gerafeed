# Task 172. Affiliate Template Constraints & Variables

Formalizar selectionMode/min/max/requiresCategory/allowsSuggestedTitle e validar placeholders suportados como product.*, products, category.name, referenceSummaries. Variável desconhecida gera erro explícito.

## Definition of Done
- [ ] schema/config
- [ ] validator
- [ ] UI help
- [ ] preview/tests
- [ ] TypeScript/Lint PASS
