# Task 155. Mercado Livre Refresh & Merge

## Atualiza
sourceDescription/specs/category/rating/reviews, seller/prices e source image metadata.

## Preserva
description/specs/pros/cons/rating editorial/ProductCategory.

## Definition of Done
- [ ] merge service
- [ ] preservation tests
- [ ] refresh fields
- [ ] diff quando necessário
- [ ] TypeScript/Lint/Tests/Build PASS
