# Task 170. Global Affiliate Prompt Migration

## Objetivo
Migrar resolver Affiliate de system default + workspace override para global-only. Preservar registros legados, não apagar automaticamente. Seed/identificar globals. Artigos novos guardam promptTemplateId/version.

## Definition of Done
- [ ] migration strategy/global resolver
- [ ] legacy preserved
- [ ] workspace override ignored
- [ ] audit fields
- [ ] tests/TypeScript/Lint/Build PASS
