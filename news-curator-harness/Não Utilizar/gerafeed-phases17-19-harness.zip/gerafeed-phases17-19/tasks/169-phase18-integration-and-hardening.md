# Task 169. Phase 18 Integration & Hardening

Cenários: RSS normal; RSS manual product; IA suggestion approved/ignored; Review; Comparison 1 bloqueado/2+ passa; Best Products; WordPress publish.

## Definition of Done
- [ ] scenarios
- [ ] tenant/entitlement
- [ ] no raw affiliateUrl canonical
- [ ] TypeScript/Lint/Tests/Build PASS
