# Task 166. Affiliate Template Input Rules

Centralizar selectionMode/minProducts/maxProducts/requiresCategory/allowsSuggestedTitle. Defaults: Review 1/1; Comparison min2; Best Products CATEGORY_AND_PRODUCTS; Buying Guide CATEGORY. UI/backend usam mesma source of truth.

## Definition of Done
- [ ] central rules
- [ ] client/server validation
- [ ] tests por tipo
- [ ] TypeScript/Lint PASS
