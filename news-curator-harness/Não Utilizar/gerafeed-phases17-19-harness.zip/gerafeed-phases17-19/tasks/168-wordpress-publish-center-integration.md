# Task 168. WordPress Publish Center Integration

RSS renderiza Article + placements. Affiliate renderiza Canonical Document. Revisar WordPressSite, category, image, SEO, links/disclosure.

## Definition of Done
- [ ] RSS normal/monetized
- [ ] Affiliate publish
- [ ] sponsored links/source attribution/status
- [ ] tests/TypeScript/Lint PASS
