# Task 160. Dashboard Information Refactor

## Objetivo
Dashboard informativo: uso, artigos, produtos, ofertas, cliques, sites, alerts, needsRepublish. Publicação operacional sai daqui.

## Definition of Done
- [ ] metrics/alerts
- [ ] no duplicate publish forms
- [ ] responsive
- [ ] TypeScript/Lint PASS
