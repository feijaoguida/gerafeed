# Task 156. Phase 17 Integration

Importar produto completo, editar editorial, refresh e provar preservação. Adicionar URL externa, resumir e usar grounding.

## Definition of Done
- [ ] import/confirm/edit/refresh
- [ ] reviews
- [ ] reference source
- [ ] tenant
- [ ] TypeScript/Lint/Tests/Build PASS
