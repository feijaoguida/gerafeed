# Task 165. Affiliate Publishing Flow

Template → inputs → categoria/produtos → título manual/sugerido → gerar → revisar → WordPress/category → publicar.

## Definition of Done
- [ ] selection/generation/preview/publish
- [ ] entitlement/tenant
- [ ] TypeScript/Lint PASS
