# Task 152. Product Review Samples

## Objetivo
Importar até 5 avaliações públicas para grounding.

## Model
ProductReviewSample: workspaceId, productId, provider, rating?, text, sourceUrl?, capturedAt.

## Regras
Sem PII desnecessária; max 5; não tratar como estatística.

## Definition of Done
- [ ] schema/migration
- [ ] provider
- [ ] max5
- [ ] UI
- [ ] refresh
- [ ] grounding formatter
- [ ] tests/TypeScript/Lint/Build PASS
