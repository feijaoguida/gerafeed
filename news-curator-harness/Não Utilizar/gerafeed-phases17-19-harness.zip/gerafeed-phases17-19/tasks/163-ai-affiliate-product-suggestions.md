# Task 163. AI Affiliate Product Suggestions

IA recebe artigo + catálogo ACTIVE/Offers ACTIVE e retorna productId, offerId?, confidence, reason, placement. IDs precisam estar na lista fornecida e ser validados no servidor. Usuário aprova/ignora.

## Definition of Done
- [ ] entitlement
- [ ] grounded structured output
- [ ] server validation
- [ ] human approval
- [ ] tests/TypeScript/Lint PASS
