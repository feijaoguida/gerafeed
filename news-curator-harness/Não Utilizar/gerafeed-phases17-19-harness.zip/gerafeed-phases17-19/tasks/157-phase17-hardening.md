# Task 157. Phase 17 Hardening

Auditar SSRF, content-type, redirects, max bytes/timeouts, source/editorial separation, review privacy/max5, category separation e grounding sem falsa estatística.

## Definition of Done
- [ ] security/data/AI checks
- [ ] TypeScript/Lint/Tests/Build PASS
