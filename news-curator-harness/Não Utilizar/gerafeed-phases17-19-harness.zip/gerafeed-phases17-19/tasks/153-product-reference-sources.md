# Task 153. Product Reference Sources

## Objetivo
Cadastrar URLs externas em Conteúdos Relacionados e gerar resumo por IA.

## Fluxo
URL → SSRF-safe fetch → readable extraction → AI summary → READY.

## UI
Adicionar, status, título, resumo, abrir fonte, remover, reprocessar.

## Definition of Done
- [ ] model/migration
- [ ] CRUD
- [ ] safe fetch
- [ ] extraction
- [ ] AI summary
- [ ] UI
- [ ] tenant/tests/TypeScript/Lint/Build PASS
