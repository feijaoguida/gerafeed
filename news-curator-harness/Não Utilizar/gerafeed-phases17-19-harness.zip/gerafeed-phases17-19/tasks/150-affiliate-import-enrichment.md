# Task 150. Affiliate Import Enrichment

## Objetivo
Corrigir MercadoLivreAffiliateProvider para preencher sourceDescription, brand, marketplaceCategory, sourceSpecs, sourceRating/count, seller, price, oldPrice e currency quando disponíveis.

## Regras
Não inventar dados; preservar SSRF; não acessar Portal autenticado; metadataSource obrigatório; preço snapshot.

## Definition of Done
- [ ] descrição
- [ ] seller/preço
- [ ] marca/categoria
- [ ] specs
- [ ] rating/count
- [ ] preview atualizado
- [ ] COMPLETE/PARTIAL correto
- [ ] fixtures
- [ ] TypeScript/Lint/Tests/Build PASS
