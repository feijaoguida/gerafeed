# Task 171. Backoffice Affiliate Prompt Manager

Criar `/backoffice/affiliate-prompts` para SuperAdmin listar, editar/versionar, ativar, description, systemPrompt, userPromptTemplate, constraints, variables e test preview.

## Definition of Done
- [ ] route/UI
- [ ] CRUD/version flow
- [ ] server-side SuperAdmin
- [ ] preview
- [ ] tests/TypeScript/Lint PASS
