# Task 162. RSS Publishing Flow

WordPressSite → feeds/artigos → notícia → gerar/revisar → categoria/imagem/SEO → publicar. Preservar Phase 8 prompt/destination resolution.

## Definition of Done
- [ ] flow completo
- [ ] legacy migration
- [ ] tests/TypeScript/Lint PASS
