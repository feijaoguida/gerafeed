# Task 167. Affiliate Generation & Preview

Input inclui global template, Workspace AI context, categoria, produtos/ofertas, source/editorial metadata, reviews e reference summaries. Output canonical document + SEO + ArticleProduct + template/version. Links não são escritos pela IA.

## Definition of Done
- [ ] input builder/generator/SEO/preview/audit
- [ ] no hallucinated products
- [ ] tests/TypeScript/Lint PASS
