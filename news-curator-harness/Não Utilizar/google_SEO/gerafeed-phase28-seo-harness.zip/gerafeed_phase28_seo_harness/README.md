# GeraFeed. Phase 28. SEO, Measurement & Organic Acquisition Foundation

## Objetivo

Adicionar a fundação técnica necessária para o GeraFeed ser rastreável, indexável, mensurável e preparado para crescer via busca orgânica, sem misturar esta fase com criação massiva de conteúdo ou refatorações de domínio.

Esta fase começa após a conclusão da Phase 27 e usa a sequência de tasks 230 a 238.

## Regra de execução

Uma task por vez.

Fluxo obrigatório:

```text
Contexto
→ Task
→ Inspeção da implementação atual
→ Plano
→ Implementação
→ Definition of Done
→ Validation
→ Evidence
→ PROGRESS
→ MEMORY/decisions quando necessário
```

Não avance automaticamente para a próxima task.

## Ordem

```text
230 → 231 → 232 → 233 → 234 → 235 → 236 → 237 → 238
```

## Tasks

- 230. SEO Public Route Policy & Metadata Baseline
- 231. Sitemap, Robots & Canonicals
- 232. Structured Data & Brand Entity
- 233. Google Tag Manager & Consent Foundation
- 234. Organic Conversion Event Tracking
- 235. Public SEO Landing Architecture
- 236. SEO Landing Pages
- 237. Blog Foundation
- 238. Technical SEO Validation & Hardening

## Pré-condição externa

Antes da Task 233, preencher `docs/google-handoff.md` com os IDs criados na Frente Google.

A verificação principal do Search Console deve preferir propriedade de domínio por DNS. Não criar dependência de meta verification no código quando a propriedade de domínio estiver verificada.

## Primeira instrução para o Agente de Código

```text
Leia AGENTS.md, SPEC.md, MEMORY.md, PROGRESS.md, docs/decisions.md,
este pacote Phase 28 e tasks/230-seo-public-route-policy-metadata.md.

A Phase 27 está concluída. Estamos iniciando a Phase 28.

Inspecione a implementação atual antes de alterar qualquer arquivo.
Implemente somente a Task 230.
Não implemente a Task 231 nem qualquer task futura.

Antes de codificar, apresente:
1. arquivos que pretende alterar;
2. comportamento atual encontrado;
3. plano de implementação;
4. riscos de regressão.

Aguarde autorização.

Ao concluir a Task 230:
1. execute Definition of Done;
2. execute TypeScript;
3. execute lint;
4. execute testes aplicáveis;
5. execute build;
6. registre Evidence;
7. atualize PROGRESS.md;
8. atualize MEMORY.md ou docs/decisions.md apenas quando necessário.
```

## Restrições da fase

- Preservar monólito Next.js App Router.
- Preservar multi-tenant e regras de autorização existentes.
- Não adicionar microserviços, fila, cron ou CMS externo para resolver SEO.
- Não alterar regras de billing, affiliate, scraping ou publicação salvo quando necessário para instrumentação de eventos sem PII.
- Não criar dezenas de páginas programáticas automaticamente.
- Não gerar reviews, estrelas, números de clientes ou estatísticas fictícias em JSON-LD.
- Não duplicar Google Analytics direto no código se GA4 estiver sendo servido pelo Google Tag Manager.
- Não enviar email, nome, CPF/CNPJ, workspaceId, IDs de usuário ou outros dados pessoais para Analytics.
- Usar o Design System GeraFeed existente em toda nova UI pública.
