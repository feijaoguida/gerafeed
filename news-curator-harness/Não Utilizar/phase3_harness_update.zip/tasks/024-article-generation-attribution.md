# Task: 024-article-generation-attribution

## Objetivo
Garantir que a imagem escolhida e o crédito da fonte sejam enviados corretamente ao WordPress.

## Contexto
É a etapa final da Fase 3: consolidar as escolhas feitas no dashboard na carga útil (payload) enviada à API do WordPress.

## Escopo
- Interceptar a rota de aprovação (`POST /api/articles/:id/approve`).
- Buscar a fonte associada à notícia para pegar o `creditName`.
- Fazer append no final do `content`: `<br><br><p><em>Fonte: ${creditName}</em></p>` (somente se `creditName` existir).
- Realizar o upload do arquivo de imagem selecionado (via endpoint de media do WP `/wp-json/wp/v2/media`) para obter o `featured_media` ID.
- Atribuir o ID gerado à chave `featured_media` do payload do post.
- Executar a publicação do post.

## Definition of Done
- [ ] Texto do crédito aparece corretamente na matéria publicada no WP.
- [ ] A imagem selecionada no dashboard aparece como Featured Image no post do WP.
- [ ] Validações de erro (falha de upload de mídia) bem tratadas.
