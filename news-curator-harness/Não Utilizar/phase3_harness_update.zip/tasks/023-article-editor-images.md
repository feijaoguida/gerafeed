# Task: 023-article-editor-images

## Objetivo
Exibir as opções de imagem na tela de aprovação para decisão humana.

## Contexto
O usuário precisa ver a imagem original e a alterada lado a lado e confirmar qual será enviada ao WordPress.

## Escopo
- Atualizar a tela de Aprovação (`app/dashboard/article/[id]`).
- Adicionar uma seção "Mídia".
- Renderizar as duas imagens (se a processada existir).
- Adicionar um Radio Button ou seletor visual para definir `selectedImage` (Original ou Alterada).
- Salvar a seleção ao clicar em "Salvar" ou "Aprovar".

## Definition of Done
- [ ] Imagens renderizadas lado a lado na UI.
- [ ] Seletor funcional atualizando o estado.
- [ ] Preferência do usuário enviada no payload de aprovação.
