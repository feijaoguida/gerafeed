# Task: 020-rss-source-credit

## Objetivo
Adicionar o campo "Fonte" ao modelo de fontes RSS para uso posterior em créditos.

## Contexto
Para dar os devidos créditos às matérias originais, precisamos que cada fonte cadastrada tenha um nome comercial de exibição.

## Escopo
- Atualizar `schema.prisma`: adicionar `creditName String?` no model `Source`.
- Gerar migração do Prisma.
- Atualizar a interface de gerenciamento de Fontes RSS (`app/settings/rss`) para incluir um campo de texto opcional "Fonte (Nome de exibição)".
- Atualizar a API de criação/edição de fontes para aceitar e salvar este campo.

## Fora do escopo
- Inserir o crédito na publicação (isso será feito na task 024).

## Definition of Done
- [ ] Schema Prisma atualizado.
- [ ] Migração aplicada com sucesso.
- [ ] UI de configurações de RSS exibe o novo campo.
- [ ] Cadastro e edição de fonte salvam o valor no banco de dados.
- [ ] TypeScript PASS.
