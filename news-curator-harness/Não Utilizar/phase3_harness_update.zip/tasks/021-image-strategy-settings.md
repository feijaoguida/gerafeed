# Task: 021-image-strategy-settings

## Objetivo
Criar a configuração central de estratégia de imagens.

## Contexto
O usuário deve poder escolher se o sistema usará imagens originais ou versões modificadas/processadas por padrão.

## Escopo
- Criar a interface de UI `Configurações > Imagens`.
- Opções: "Usar imagem original" ou "Processar/Alterar imagem".
- Salvar a escolha na tabela `Configuration` com a key `imageSettings`.

## Definition of Done
- [ ] Tela de configuração de imagens criada.
- [ ] Leitura e gravação na tabela `Configuration` funcionando.
- [ ] Nenhuma quebra no layout do menu lateral.
