# Task: 022-image-processing-pipeline

## Objetivo
Criar o serviço de backend que processa a imagem original criando a versão modificada.

## Contexto
Quando uma notícia for processada e tiver uma `originalImageUrl`, o sistema deve baixar, aplicar a alteração (ex: inversão horizontal via biblioteca `sharp`) e disponibilizar a nova URL.

## Escopo
- Atualizar `schema.prisma`: adicionar `modifiedImageUrl String?` e `selectedImage String? @default("ORIGINAL")` no model `Article`.
- Instalar biblioteca `sharp`.
- Criar serviço (`src/lib/imageProcessor.ts`) que receba uma URL, baixe o buffer, inverta a imagem horizontalmente (`.flop()`) e aplique uma mudança sutil (ex: leve ajuste de contraste).
- Salvar o resultado (pode ser temporariamente na pasta `public/media` ou local storage simulado).
- Integrar esse passo ao final do `processArticle` (se a configuração global mandar alterar).

## Fora do escopo
- Envio para o WordPress (isso ocorre na publicação).

## Definition of Done
- [ ] Banco atualizado.
- [ ] Processador de imagem funcional.
- [ ] O processamento da notícia salva a `modifiedImageUrl` no banco quando aplicável.
