# News Curator. Phase 3

## 1. Objetivo
Evoluir o sistema para gerenciar mídias (imagens) de forma inteligente e garantir a devida atribuição (créditos) às fontes originais.

Nesta fase:
- Campo "Fonte" no cadastro de RSS.
- Configuração global de estratégia de imagens (Original vs. Processada/IA).
- Processamento de imagens (inversão, filtros sutis ou IA) para diferenciação.
- Comparação visual (Original x Alterada) na tela de aprovação.
- Inserção automática dos créditos no final do artigo gerado.

## 2. AI Provider e Processamento
O fluxo existente de `AIProvider` permanece. A novidade é a etapa de processamento de imagem que ocorre após a coleta e antes (ou durante) a aprovação.

## 3. Configuração central
Adicionar nova chave na tabela `Configuration`:
- `imageSettings` (JSON)
  Exemplo de valor: `{ "strategy": "MODIFIED", "modificationType": "FLIP_HORIZONTAL" }`

## 4. WordPress
A publicação no WordPress agora deve enviar a imagem escolhida (Original ou Alterada) como `featured_media`. O upload da imagem para o media library do WP deve ocorrer na aprovação, ou a URL externa deve ser usada (se o WP estiver configurado para aceitar).

## 5. Criptografia
Sem mudanças estruturais nesta fase.

## 6. Telas e UI
### Cadastro de RSS
Adicionar campo opcional "Fonte". Descrição: "Usado para informar no final das Matérias".

### Configurações de Imagem
Nova aba ou seção em Configurações para escolher a estratégia padrão de imagens.

### Editor de Aprovação
O painel de edição do artigo deve exibir:
- Imagem Original (com label).
- Imagem Alterada (com label).
Permitir que o usuário selecione qual versão será publicada (radio button ou seleção visual).

## 7. Geração e Atribuição
No momento de montar o conteúdo final para o WordPress, o sistema deve concatenar automaticamente:
`<br><br><p><em>Fonte: {Nome da Fonte}</em></p>` (ou formato equivalente) no final do `content`.

## 8. Definition of Done global (Phase 3)
- [ ] Schema do Prisma atualizado (Source.creditName, Article.modifiedImageUrl).
- [ ] Cadastro de RSS refatorado para incluir campo Fonte.
- [ ] Configuração de Estratégia de Imagem criada no banco e na UI.
- [ ] Pipeline de processamento de imagem implementado (Sharp para inversão/filtros ou integração IA).
- [ ] Tela de aprovação exibindo as duas versões da imagem lado a lado.
- [ ] Seleção de imagem final pelo usuário.
- [ ] Artigo publicado contendo a atribuição (Fonte) no final do texto.
- [ ] Imagem correta enviada ao WordPress.
- [ ] TypeScript PASS, Lint PASS.
