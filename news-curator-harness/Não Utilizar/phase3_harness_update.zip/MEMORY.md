# MEMORY.md. Memória Permanente

## Produto
- News Curator coleta notícias via RSS, prepara conteúdo com IA, permite revisão humana e publica no WordPress.
- Nenhuma notícia publica sem aprovação explícita.
- **Fase 3**: Artigos devem incluir os créditos originais. Imagens podem ser originais ou processadas/modificadas para evitar duplicidade exata.

## Banco de dados
- PostgreSQL + Prisma.
- Tabela `Configuration` para settings (ex: `wordpressConnection`, `aiProvider`, `imageSettings`).
- **Novos Campos (Fase 3)**:
  - `Source.creditName` (String, opcional).
  - `Article.modifiedImageUrl` (String, opcional).
  - `Article.selectedImage` (Enum/String: 'ORIGINAL' | 'MODIFIED').

## Stack e Ferramentas Adicionais
- Next.js App Router, TypeScript, Prisma, Tailwind.
- Processamento de Imagens: Utilizar biblioteca `sharp` no Node.js para transformações programáticas leves (inversão, filtros) ou chamadas de API externas se optado por IA visual.

## Segredos e Criptografia
- Segredos encriptados em AES-256-GCM (Phase 2).

## AI Provider
- Interface `AIProvider` agnóstica de fornecedor.

## WordPress
- Publicação usa REST API nativa (`/wp-json/wp/v2/`).
- Envio de mídia para o WP (`/wp-json/wp/v2/media`) será necessário caso a imagem processada seja gerada localmente.
