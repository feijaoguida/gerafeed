# Task 183. Hosted Checkout & Billing Methods

## Status
TODO

## Objetivo

Criar jornada de contratação sem receber dados brutos de cartão.

## Billing Method

Domínio:

```text
CREDIT_CARD
BOLETO
PIX
```

Provider expõe capabilities.

## CREDIT_CARD

Preferir Asaas Hosted Checkout.

Fluxo:
- validar plan/cycle;
- calcular amount;
- BillingProfile;
- Customer sync;
- criar BillingCheckoutSession;
- criar Checkout;
- salvar providerCheckoutId;
- retornar link;
- redirect.

## Callback

Callback:
- não ativa plano;
- não marca Invoice como paga;
- mostra estado "aguardando confirmação".

## BOLETO / PIX

Podem seguir fluxo direto de Subscription quando suportados pelo provider.

Não misturar com card data.

## CheckoutSession

Criar/reutilizar model conforme SPEC.

## Segurança

- URLs callback conhecidas.
- externalReference interna.
- não aceitar amount enviado pelo browser como fonte da verdade.
- plan/cycle são resolvidos server-side.
- client nunca envia annualAmount final confiável.

## Definition of Done

- [ ] billing method enum.
- [ ] capability matrix.
- [ ] CheckoutSession.
- [ ] hosted card checkout.
- [ ] amount calculado server-side.
- [ ] callback seguro.
- [ ] sem card data.
- [ ] expired/cancel status.
- [ ] tests.
- [ ] TypeScript/Lint/Build PASS.

## Evidence

Sandbox Checkout criado sem qualquer card field trafegando pelo backend.
