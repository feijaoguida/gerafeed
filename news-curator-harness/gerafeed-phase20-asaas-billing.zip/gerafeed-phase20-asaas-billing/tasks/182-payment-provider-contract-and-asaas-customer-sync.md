# Task 182. PaymentProvider Contract & Asaas Customer Sync

## Status
TODO

## Objetivo

Evoluir PaymentProvider e implementar sincronização idempotente de Customer Asaas.

## PaymentProvider v2

Adicionar contratos/capabilities necessários para:
- customer;
- checkout;
- subscription;
- payments;
- webhooks.

Não quebrar código existente.

## Asaas Customer

Fluxo:

```text
BillingProfile
→ providerCustomerId existe?
├── sim: recuperar/atualizar
└── não:
    → procurar/reconciliar quando aplicável
    → criar
    → salvar ID
```

## externalReference

Enviar referência interna estável do Workspace.

## Duplicidade

Não criar customer a cada tentativa de checkout.

## Provider DTO

Normalizar resposta.

Não retornar payload cru Asaas ao client.

## Definition of Done

- [ ] PaymentProvider v2.
- [ ] capabilities.
- [ ] AsaasProvider adaptado.
- [ ] create/update customer.
- [ ] providerCustomerId persistido.
- [ ] externalReference.
- [ ] retry idempotente.
- [ ] duplicate prevention.
- [ ] error normalization.
- [ ] sandbox test.
- [ ] TypeScript/Lint/Tests/Build PASS.

## Evidence

Registrar Customer criado e segunda execução reutilizando o mesmo ID.
