# Task 181. Billing Profile & Customer Data

## Status
TODO

## Objetivo

Criar/reutilizar o perfil cadastral de cobrança de cada Workspace sem armazenar dados de cartão.

## Inspeção obrigatória

Antes de criar tabela:
- verificar campos existentes em Workspace;
- verificar User;
- verificar Subscription;
- verificar billing já implementado.

Evitar duplicação.

## Modelo sugerido

```text
BillingProfile
id
workspaceId @unique
name
cpfCnpj
email
mobilePhone?
postalCode?
address?
addressNumber?
complement?
province?
city?
providerCustomerId?
createdAt
updatedAt
```

## PII

- CPF/CNPJ deve ser protegido na UI quando não houver necessidade de exibição completa.
- não logar documento completo.
- validar tenant.
- SuperAdmin pode consultar via Backoffice.
- usuário comum só vê Workspace atual.

## UI

`Configurações > Plano e cobrança > Dados de cobrança`

Campos cadastrais.

Não incluir:
- cartão;
- CVV;
- validade.

## Definition of Done

- [ ] schema/reuse decidido.
- [ ] migration quando necessária.
- [ ] 1 profile por Workspace.
- [ ] create/update/read.
- [ ] validation CPF/CNPJ conforme política existente.
- [ ] tenant isolation.
- [ ] masking quando aplicável.
- [ ] sem card fields.
- [ ] tests.
- [ ] TypeScript/Lint/Build PASS.

## Evidence

Registrar model adotado e validações.
