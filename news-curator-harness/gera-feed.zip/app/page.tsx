import { SiteHeader } from '@/components/gerafeed/site-header'
import { Hero } from '@/components/gerafeed/hero'
import { ProblemSolution } from '@/components/gerafeed/problem-solution'
import { HowItWorks } from '@/components/gerafeed/how-it-works'
import { Features } from '@/components/gerafeed/features'
import { Differentiators } from '@/components/gerafeed/differentiators'
import { Testimonials } from '@/components/gerafeed/testimonials'
import { Audience } from '@/components/gerafeed/audience'
import { Pricing } from '@/components/gerafeed/pricing'
import { Faq } from '@/components/gerafeed/faq'
import { FinalCta } from '@/components/gerafeed/final-cta'
import { SiteFooter } from '@/components/gerafeed/site-footer'

export default function Page() {
  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <main>
        <Hero />
        <ProblemSolution />
        <HowItWorks />
        <Features />
        <Differentiators />
        <Testimonials />
        <Audience />
        <Pricing />
        <Faq />
        <FinalCta />
      </main>
      <SiteFooter />
    </div>
  )
}
