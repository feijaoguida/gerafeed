import { Analytics } from '@vercel/analytics/next'
import type { Metadata, Viewport } from 'next'
import { Inter, Plus_Jakarta_Sans } from 'next/font/google'
import './globals.css'

const inter = Inter({
  subsets: ['latin'],
  variable: '--font-inter',
  display: 'swap',
})

const jakarta = Plus_Jakarta_Sans({
  subsets: ['latin'],
  weight: ['500', '600', '700', '800'],
  variable: '--font-jakarta',
  display: 'swap',
})

export const metadata: Metadata = {
  metadataBase: new URL('https://gerafeed.com'),
  title: 'GeraFeed — Automatize seu Blog com Curadoria de Notícias por IA',
  description:
    'O GeraFeed coleta feeds RSS, reescreve com IA, processa imagens anti-plágio e publica direto no seu WordPress. Escale sua produção de conteúdo sem perder qualidade. Comece grátis, sem cartão.',
  keywords: [
    'curadoria de conteúdo com IA',
    'automação de blog',
    'RSS para WordPress',
    'reescrita de artigos com inteligência artificial',
    'SEO automático',
    'GeraFeed',
  ],
  authors: [{ name: 'GeraFeed' }],
  openGraph: {
    title: 'GeraFeed — Automatize seu Blog com Curadoria de Notícias por IA',
    description:
      'Coleta RSS, reescrita com IA, imagens anti-plágio e publicação automática no WordPress. Comece grátis hoje mesmo.',
    type: 'website',
    locale: 'pt_BR',
    siteName: 'GeraFeed',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'GeraFeed — Curadoria de Conteúdo com IA para WordPress',
    description:
      'Automatize a coleta, reescrita e publicação de artigos no seu WordPress com Inteligência Artificial.',
  },
  generator: 'v0.app',
}

export const viewport: Viewport = {
  colorScheme: 'light',
  themeColor: '#312e81',
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="pt-BR" className={`light ${inter.variable} ${jakarta.variable} bg-background`}>
      <body className="font-sans antialiased">
        {children}
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
