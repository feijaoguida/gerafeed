'use client'

import { Briefcase, PenTool, TrendingUp } from 'lucide-react'
import { Reveal } from './reveal'

const archetypes = [
  {
    icon: PenTool,
    title: 'Donos de blog',
    desc: 'Publique com consistência mesmo sem tempo. Mantenha o calendário editorial sempre cheio.',
    quote: '"Meu blog nunca mais ficou uma semana sem post novo."',
  },
  {
    icon: Briefcase,
    title: 'Agências de marketing',
    desc: 'Gerencie vários WordPress de clientes em um só painel, com fluxo de aprovação organizado.',
    quote: '"Escalei de 3 para 8 clientes sem contratar redatores."',
  },
  {
    icon: TrendingUp,
    title: 'Afiliados e criadores',
    desc: 'Produza volume com SEO embutido para capturar mais tráfego e converter mais comissões.',
    quote: '"Mais artigos ranqueando = mais receita recorrente."',
  },
]

export function Audience() {
  return (
    <section className="border-b border-border py-20 lg:py-28">
      <div className="mx-auto max-w-6xl px-4 sm:px-6">
        <Reveal className="mx-auto max-w-2xl text-center">
          <span className="text-sm font-bold uppercase tracking-wider text-primary">Para quem é</span>
          <h2 className="mt-3 text-balance font-display text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
            Feito para quem precisa de escala sem perder qualidade
          </h2>
        </Reveal>

        <div className="mt-14 grid gap-6 md:grid-cols-3">
          {archetypes.map((a, i) => (
            <Reveal
              as="article"
              key={a.title}
              delay={i}
              className="rounded-2xl border border-border bg-card p-7"
            >
              <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-cta/15 text-cta-foreground">
                <a.icon className="h-6 w-6 text-primary" aria-hidden="true" />
              </span>
              <h3 className="mt-4 font-display text-lg font-bold text-foreground">{a.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{a.desc}</p>
              <p className="mt-4 border-l-2 border-cta pl-3 text-sm font-medium italic text-foreground">
                {a.quote}
              </p>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  )
}
