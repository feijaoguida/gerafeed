'use client'

import { ArrowRight, Check } from 'lucide-react'
import { Reveal } from './reveal'

const recap = ['Sem cartão de crédito', 'Configuração em minutos', 'Cancele quando quiser']

export function FinalCta() {
  return (
    <section className="py-20 lg:py-28">
      <div className="mx-auto max-w-6xl px-4 sm:px-6">
        <Reveal className="relative overflow-hidden rounded-3xl border border-primary/30 bg-primary px-6 py-16 text-center text-primary-foreground sm:px-12">
          <div
            aria-hidden="true"
            className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_50%_60%_at_50%_0%,color-mix(in_oklch,var(--cta)_25%,transparent),transparent)]"
          />
          <div className="relative mx-auto max-w-2xl">
            <h2 className="text-balance font-display text-3xl font-extrabold tracking-tight sm:text-4xl">
              Pronto para escalar sua produção de conteúdo?
            </h2>
            <p className="mx-auto mt-4 max-w-xl text-pretty text-lg text-primary-foreground/85">
              Junte-se a milhares de criadores e agências que já geraram mais de 10.000 artigos
              com o GeraFeed. Comece grátis hoje mesmo.
            </p>

            <div className="mt-8 flex justify-center">
              <a
                href="#"
                className="group inline-flex items-center gap-2 rounded-xl bg-cta px-8 py-4 text-base font-bold text-cta-foreground shadow-lg shadow-cta/30 transition-transform hover:-translate-y-0.5"
              >
                Criar minha conta gratuita agora
                <ArrowRight className="h-5 w-5 transition-transform group-hover:translate-x-1" aria-hidden="true" />
              </a>
            </div>

            <ul className="mt-8 flex flex-wrap items-center justify-center gap-x-6 gap-y-2">
              {recap.map((r) => (
                <li key={r} className="flex items-center gap-2 text-sm font-medium text-primary-foreground/90">
                  <Check className="h-4 w-4 text-cta" aria-hidden="true" />
                  {r}
                </li>
              ))}
            </ul>
          </div>
        </Reveal>
      </div>
    </section>
  )
}
