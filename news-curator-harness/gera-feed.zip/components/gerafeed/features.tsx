'use client'

import { BrainCircuit, ImageIcon, Plug, ShieldCheck } from 'lucide-react'
import { Reveal } from './reveal'

const features = [
  {
    icon: BrainCircuit,
    title: 'Multi-IA nativa',
    desc: 'Suporte a OpenAI, Gemini e Anthropic. Escolha o modelo ideal para cada tipo de pauta.',
  },
  {
    icon: Plug,
    title: 'Publicação via WordPress REST API',
    desc: 'Integração direta e segura com o seu WordPress. Publique ou agende sem sair da plataforma.',
  },
  {
    icon: ImageIcon,
    title: 'Imagens anti-plágio',
    desc: 'Processamento inteligente que gera imagens originais e evita duplicidade prejudicial ao SEO.',
  },
  {
    icon: ShieldCheck,
    title: 'Atribuição automática de fonte',
    desc: 'Segurança jurídica com créditos e referências aplicados automaticamente a cada artigo.',
  },
]

export function Features() {
  return (
    <section id="funcionalidades" className="scroll-mt-20 border-b border-border bg-secondary/40 py-20 lg:py-28">
      <div className="mx-auto max-w-6xl px-4 sm:px-6">
        <Reveal className="mx-auto max-w-2xl text-center">
          <span className="text-sm font-bold uppercase tracking-wider text-primary">Funcionalidades</span>
          <h2 className="mt-3 text-balance font-display text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
            Tudo o que seu blog precisa para escalar com autoridade
          </h2>
          <p className="mt-4 text-pretty text-lg text-muted-foreground">
            Recursos pensados para performance de SEO, produtividade e segurança do seu domínio.
          </p>
        </Reveal>

        <div className="mt-14 grid gap-6 sm:grid-cols-2">
          {features.map((f, i) => (
            <Reveal
              key={f.title}
              delay={i}
              className="flex gap-5 rounded-2xl border border-border bg-card p-7"
            >
              <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-primary text-primary-foreground">
                <f.icon className="h-6 w-6" aria-hidden="true" />
              </span>
              <div>
                <h3 className="font-display text-lg font-bold text-foreground">{f.title}</h3>
                <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">{f.desc}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  )
}
