import { Rss } from 'lucide-react'

const columns = [
  {
    title: 'Produto',
    links: ['Funcionalidades', 'Como Funciona', 'Preços', 'Integrações'],
  },
  {
    title: 'Recursos',
    links: ['Blog', 'Guia de SEO', 'Central de Ajuda', 'Status'],
  },
  {
    title: 'Legal',
    links: ['Termos de Uso', 'Política de Privacidade', 'LGPD', 'Cookies'],
  },
]

export function SiteFooter() {
  return (
    <footer className="border-t border-border bg-secondary/40">
      <div className="mx-auto max-w-6xl px-4 py-14 sm:px-6">
        <div className="grid gap-10 md:grid-cols-[1.5fr_1fr_1fr_1fr]">
          <div>
            <div className="flex items-center gap-2">
              <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary text-primary-foreground">
                <Rss className="h-4 w-4" aria-hidden="true" />
              </span>
              <span className="font-display text-lg font-extrabold tracking-tight text-foreground">
                GeraFeed
              </span>
            </div>
            <p className="mt-4 max-w-xs text-sm leading-relaxed text-muted-foreground">
              Curadoria de conteúdo com Inteligência Artificial: do feed RSS ao WordPress,
              com SEO e imagens originais.
            </p>
          </div>

          {columns.map((col) => (
            <nav key={col.title} aria-label={col.title}>
              <h2 className="text-sm font-semibold text-foreground">{col.title}</h2>
              <ul className="mt-4 space-y-3">
                {col.links.map((link) => (
                  <li key={link}>
                    <a
                      href="#"
                      className="text-sm text-muted-foreground transition-colors hover:text-foreground"
                    >
                      {link}
                    </a>
                  </li>
                ))}
              </ul>
            </nav>
          ))}
        </div>

        <div className="mt-12 flex flex-col items-center justify-between gap-4 border-t border-border pt-8 sm:flex-row">
          <p className="text-sm text-muted-foreground">
            © {new Date().getFullYear()} GeraFeed. Todos os direitos reservados.
          </p>
          <p className="text-sm text-muted-foreground">Feito para criadores que querem escalar.</p>
        </div>
      </div>
    </footer>
  )
}
