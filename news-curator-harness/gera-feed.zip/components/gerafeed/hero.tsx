'use client'

import { ArrowRight, CheckCircle2, Sparkles, Star } from 'lucide-react'
import { Reveal } from './reveal'

const valueBullets = [
  'Coleta RSS ilimitada e automática',
  'Reescrita única e otimizada para SEO',
  'Publicação direta no seu WordPress',
]

export function Hero() {
  return (
    <section className="relative overflow-hidden border-b border-border">
      {/* fundo sutil com grid */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_60%_50%_at_50%_-10%,color-mix(in_oklch,var(--primary)_18%,transparent),transparent)]"
      />
      <div className="relative mx-auto max-w-6xl px-4 py-20 sm:px-6 lg:py-28">
        <div className="mx-auto max-w-3xl text-center">
          <Reveal>
            <span className="inline-flex items-center gap-2 rounded-full border border-border bg-secondary px-4 py-1.5 text-xs font-semibold text-secondary-foreground">
              <Sparkles className="h-3.5 w-3.5 text-primary" aria-hidden="true" />
              Curadoria de conteúdo com Inteligência Artificial
            </span>
          </Reveal>

          <Reveal delay={1}>
            <h1 className="mt-6 text-balance font-display text-4xl font-extrabold leading-[1.1] tracking-tight text-foreground sm:text-5xl lg:text-6xl">
              Automatize seu Blog com Curadoria de Notícias via Inteligência Artificial
            </h1>
          </Reveal>

          <Reveal delay={2}>
            <p className="mx-auto mt-6 max-w-2xl text-pretty text-lg leading-relaxed text-muted-foreground">
              Pare de perder horas caçando e reescrevendo pautas. O GeraFeed coleta feeds RSS,
              cria conteúdo único otimizado para SEO e publica direto no seu WordPress.
              Comece grátis hoje mesmo.
            </p>
          </Reveal>

          <Reveal delay={3}>
            <ul className="mx-auto mt-8 flex max-w-xl flex-col items-center justify-center gap-3 sm:flex-row sm:flex-wrap sm:gap-x-6">
              {valueBullets.map((b) => (
                <li key={b} className="flex items-center gap-2 text-sm font-medium text-foreground">
                  <CheckCircle2 className="h-4 w-4 text-cta" aria-hidden="true" />
                  {b}
                </li>
              ))}
            </ul>
          </Reveal>

          <Reveal delay={4}>
            <div className="mt-10 flex flex-col items-center gap-3">
              <a
                href="#precos"
                className="group inline-flex items-center gap-2 rounded-xl bg-cta px-8 py-4 text-base font-bold text-cta-foreground shadow-lg shadow-cta/30 transition-transform hover:-translate-y-0.5"
              >
                Criar Conta Grátis
                <ArrowRight className="h-5 w-5 transition-transform group-hover:translate-x-1" aria-hidden="true" />
              </a>
              <p className="text-sm text-muted-foreground">
                Não exige cartão de crédito. Traga sua própria API Key no plano grátis.
              </p>
            </div>
          </Reveal>

          <Reveal delay={5}>
            <div className="mt-12 flex flex-col items-center justify-center gap-3 sm:flex-row sm:gap-4">
              <div className="flex items-center gap-1" aria-hidden="true">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star key={i} className="h-4 w-4 fill-cta text-cta" />
                ))}
              </div>
              <p className="text-sm font-medium text-muted-foreground">
                <span className="font-bold text-foreground">Mais de 10.000 artigos</span> já gerados
                por agências e criadores.
              </p>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  )
}
