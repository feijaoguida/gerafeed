'use client'

import { useState } from 'react'
import { ChevronDown } from 'lucide-react'
import { Reveal } from './reveal'

const faqs = [
  {
    q: 'Preciso da minha própria chave da OpenAI?',
    a: 'No plano Starter (grátis), sim: você usa o modelo freemium trazendo a sua própria API Key (Bring Your Own Key) da OpenAI, Gemini ou Anthropic. Nos planos Creator e Scale a IA já está inclusa — você não precisa se preocupar com chaves nem com custos de API separados.',
  },
  {
    q: 'Funciona com qualquer WordPress?',
    a: 'Sim. O GeraFeed publica através da WordPress REST API oficial, compatível com praticamente qualquer instalação WordPress moderna (auto-hospedada ou em provedores gerenciados). Basta conectar com suas credenciais e escolher publicar ou agendar.',
  },
  {
    q: 'O conteúdo gerado é plágio?',
    a: 'Não. A IA reescreve cada pauta com uma voz única, não faz cópia literal, e as imagens passam por processamento inteligente para evitar duplicidade. Além disso, aplicamos atribuição automática de fonte, garantindo segurança jurídica e boas práticas de SEO.',
  },
  {
    q: 'Quanto tempo leva para configurar?',
    a: 'Minutos. Você conecta suas fontes RSS, conecta seu WordPress e define o tom desejado. A partir daí o conteúdo passa a ser gerado automaticamente, aguardando apenas a sua aprovação de 1 clique.',
  },
  {
    q: 'Posso cancelar quando quiser?',
    a: 'Sim. Não há fidelidade. Você pode fazer upgrade, downgrade ou cancelar a qualquer momento, direto no painel.',
  },
]

function FaqItem({ q, a }: { q: string; a: string }) {
  const [open, setOpen] = useState(false)
  return (
    <div className="border-b border-border">
      <h3>
        <button
          type="button"
          onClick={() => setOpen((v) => !v)}
          className="flex w-full items-center justify-between gap-4 py-5 text-left"
          aria-expanded={open}
        >
          <span className="font-display text-base font-semibold text-foreground">{q}</span>
          <ChevronDown
            className={`h-5 w-5 shrink-0 text-primary transition-transform ${open ? 'rotate-180' : ''}`}
            aria-hidden="true"
          />
        </button>
      </h3>
      <div
        className={`grid transition-all duration-300 ${open ? 'grid-rows-[1fr] pb-5' : 'grid-rows-[0fr]'}`}
      >
        <div className="overflow-hidden">
          <p className="text-pretty leading-relaxed text-muted-foreground">{a}</p>
        </div>
      </div>
    </div>
  )
}

export function Faq() {
  return (
    <section id="faq" className="scroll-mt-20 border-b border-border py-20 lg:py-28">
      <div className="mx-auto max-w-3xl px-4 sm:px-6">
        <Reveal className="text-center">
          <span className="text-sm font-bold uppercase tracking-wider text-primary">FAQ</span>
          <h2 className="mt-3 text-balance font-display text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
            Tem alguma dúvida? A gente responde.
          </h2>
        </Reveal>

        <Reveal delay={1} className="mt-10">
          {faqs.map((f) => (
            <FaqItem key={f.q} q={f.q} a={f.a} />
          ))}
        </Reveal>
      </div>
    </section>
  )
}
