'use client'

import { Check, Clock, Copy, Frown, Languages, Sparkles, X, Zap } from 'lucide-react'
import { Reveal } from './reveal'

const oldWay = [
  { icon: Clock, text: 'Horas todos os dias caçando pautas em dezenas de sites.' },
  { icon: Copy, text: 'Copiar, colar e reescrever manualmente cada artigo.' },
  { icon: Languages, text: 'Traduzir e adaptar conteúdo à mão, sem padrão.' },
  { icon: Frown, text: 'Risco de plágio e imagens duplicadas derrubando seu SEO.' },
]

const newWay = [
  { text: 'Fontes RSS coletadas automaticamente, 24 horas por dia.' },
  { text: 'IA reescreve com voz única e SEO já embutido (title, meta, keywords).' },
  { text: 'Imagens processadas para serem originais e livres de duplicidade.' },
  { text: 'Aprovação em 1 clique e publicação direta no WordPress.' },
]

export function ProblemSolution() {
  return (
    <section className="border-b border-border bg-secondary/40 py-20 lg:py-28">
      <div className="mx-auto max-w-6xl px-4 sm:px-6">
        <Reveal className="mx-auto max-w-2xl text-center">
          <h2 className="text-balance font-display text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
            O jeito antigo esgota você. O GeraFeed trabalha por você.
          </h2>
          <p className="mt-4 text-pretty text-lg text-muted-foreground">
            A diferença entre passar o dia produzindo conteúdo e aprovar conteúdo pronto em segundos.
          </p>
        </Reveal>

        <div className="mt-14 grid gap-6 lg:grid-cols-2">
          <Reveal className="rounded-2xl border border-border bg-card p-8">
            <div className="mb-6 flex items-center gap-3">
              <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-destructive/10 text-destructive">
                <X className="h-5 w-5" aria-hidden="true" />
              </span>
              <h3 className="font-display text-xl font-bold text-foreground">Sem o GeraFeed</h3>
            </div>
            <ul className="space-y-4">
              {oldWay.map((item) => (
                <li key={item.text} className="flex items-start gap-3">
                  <item.icon className="mt-0.5 h-5 w-5 shrink-0 text-muted-foreground" aria-hidden="true" />
                  <span className="text-muted-foreground">{item.text}</span>
                </li>
              ))}
            </ul>
          </Reveal>

          <Reveal delay={1} className="relative overflow-hidden rounded-2xl border border-primary/30 bg-primary p-8 text-primary-foreground">
            <div className="mb-6 flex items-center gap-3">
              <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-cta text-cta-foreground">
                <Zap className="h-5 w-5" aria-hidden="true" />
              </span>
              <h3 className="font-display text-xl font-bold">Com o GeraFeed</h3>
            </div>
            <ul className="space-y-4">
              {newWay.map((item) => (
                <li key={item.text} className="flex items-start gap-3">
                  <Check className="mt-0.5 h-5 w-5 shrink-0 text-cta" aria-hidden="true" />
                  <span className="text-primary-foreground/90">{item.text}</span>
                </li>
              ))}
            </ul>
            <div className="mt-6 flex items-center gap-2 rounded-lg bg-primary-foreground/10 px-4 py-3 text-sm font-semibold">
              <Sparkles className="h-4 w-4 text-cta" aria-hidden="true" />
              Aprovação em 1 clique — do RSS ao WordPress.
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  )
}
