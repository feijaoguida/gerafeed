'use client'

import { Check, Minus } from 'lucide-react'
import { Reveal } from './reveal'

const rows = [
  { label: 'Coleta automática de RSS', gera: true, manual: false },
  { label: 'Reescrita única com IA', gera: true, manual: false },
  { label: 'SEO aplicado automaticamente', gera: true, manual: false },
  { label: 'Imagens originais anti-plágio', gera: true, manual: false },
  { label: 'Publicação direta no WordPress', gera: true, manual: false },
  { label: 'Atribuição de fonte automática', gera: true, manual: false },
  { label: 'Horas de trabalho manual por dia', gera: false, manual: true },
]

export function Differentiators() {
  return (
    <section className="border-b border-border py-20 lg:py-28">
      <div className="mx-auto max-w-4xl px-4 sm:px-6">
        <Reveal className="mx-auto max-w-2xl text-center">
          <span className="text-sm font-bold uppercase tracking-wider text-primary">Por que o GeraFeed</span>
          <h2 className="mt-3 text-balance font-display text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
            O que nos diferencia do processo manual
          </h2>
        </Reveal>

        <Reveal delay={1} className="mt-12 overflow-hidden rounded-2xl border border-border bg-card">
          <table className="w-full text-left">
            <caption className="sr-only">
              Comparação entre o GeraFeed e o processo manual de curadoria de conteúdo
            </caption>
            <thead>
              <tr className="border-b border-border bg-secondary/60">
                <th scope="col" className="px-5 py-4 text-sm font-semibold text-foreground">
                  Recurso
                </th>
                <th scope="col" className="px-5 py-4 text-center text-sm font-bold text-primary">
                  GeraFeed
                </th>
                <th scope="col" className="px-5 py-4 text-center text-sm font-semibold text-muted-foreground">
                  Processo Manual
                </th>
              </tr>
            </thead>
            <tbody>
              {rows.map((row) => (
                <tr key={row.label} className="border-b border-border last:border-0">
                  <th scope="row" className="px-5 py-4 text-sm font-medium text-foreground">
                    {row.label}
                  </th>
                  <td className="px-5 py-4 text-center">
                    <span className="inline-flex items-center justify-center">
                      {row.gera ? (
                        <Check className="h-5 w-5 text-cta" aria-label="Sim" />
                      ) : (
                        <Minus className="h-5 w-5 text-muted-foreground" aria-label="Não" />
                      )}
                    </span>
                  </td>
                  <td className="px-5 py-4 text-center">
                    <span className="inline-flex items-center justify-center">
                      {row.manual ? (
                        <Check className="h-5 w-5 text-muted-foreground" aria-label="Sim" />
                      ) : (
                        <Minus className="h-5 w-5 text-muted-foreground/50" aria-label="Não" />
                      )}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </Reveal>
      </div>
    </section>
  )
}
