'use client'

import { Star } from 'lucide-react'
import { Reveal } from './reveal'

const reviews = [
  {
    quote:
      'Reduzi de 6 horas para 20 minutos por dia. A reescrita da IA mantém a voz do meu blog e o tráfego orgânico subiu 40% em dois meses.',
    name: 'Rafael M.',
    role: 'Dono de blog de tecnologia',
    initials: 'RM',
  },
  {
    quote:
      'Gerencio conteúdo para 8 clientes. Com o auto-publishing e o multi-WordPress, o GeraFeed virou o coração da minha agência.',
    name: 'Camila S.',
    role: 'Agência de marketing de conteúdo',
    initials: 'CS',
  },
  {
    quote:
      'As imagens anti-plágio e a atribuição automática de fonte me deram a segurança que eu precisava para escalar sem medo.',
    name: 'Diego P.',
    role: 'Afiliado e criador de conteúdo',
    initials: 'DP',
  },
]

export function Testimonials() {
  return (
    <section className="border-b border-border bg-secondary/40 py-20 lg:py-28">
      <div className="mx-auto max-w-6xl px-4 sm:px-6">
        <Reveal className="mx-auto max-w-2xl text-center">
          <h2 className="text-balance font-display text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
            Criadores e agências que já escalaram com o GeraFeed
          </h2>
          <p className="mt-4 text-pretty text-lg text-muted-foreground">
            Junte-se a milhares de profissionais que produzem mais, com menos esforço.
          </p>
        </Reveal>

        <div className="mt-14 grid gap-6 lg:grid-cols-3">
          {reviews.map((r, i) => (
            <Reveal
              as="article"
              key={r.name}
              delay={i}
              className="flex flex-col rounded-2xl border border-border bg-card p-7"
            >
              <div className="flex items-center gap-1" aria-label="Avaliação 5 de 5 estrelas">
                {Array.from({ length: 5 }).map((_, s) => (
                  <Star key={s} className="h-4 w-4 fill-cta text-cta" aria-hidden="true" />
                ))}
              </div>
              <blockquote className="mt-4 flex-1 text-pretty leading-relaxed text-foreground">
                {`"${r.quote}"`}
              </blockquote>
              <footer className="mt-6 flex items-center gap-3">
                <span className="flex h-10 w-10 items-center justify-center rounded-full bg-primary text-sm font-bold text-primary-foreground">
                  {r.initials}
                </span>
                <div>
                  <p className="text-sm font-semibold text-foreground">{r.name}</p>
                  <p className="text-xs text-muted-foreground">{r.role}</p>
                </div>
              </footer>
            </Reveal>
          ))}
        </div>

        <Reveal delay={1} className="mt-12 flex flex-wrap items-center justify-center gap-x-8 gap-y-3 text-sm font-semibold text-muted-foreground">
          <span className="text-xs uppercase tracking-wider">Confiado por criadores em</span>
          <span>WordPress</span>
          <span aria-hidden="true">·</span>
          <span>OpenAI</span>
          <span aria-hidden="true">·</span>
          <span>Google Gemini</span>
          <span aria-hidden="true">·</span>
          <span>Anthropic</span>
        </Reveal>
      </div>
    </section>
  )
}
