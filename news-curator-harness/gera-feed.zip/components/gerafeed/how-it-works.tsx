'use client'

import { ImageIcon, PenLine, Rss, UploadCloud } from 'lucide-react'
import { Reveal } from './reveal'

const steps = [
  {
    icon: Rss,
    title: 'Conecte suas fontes RSS',
    desc: 'Adicione seus feeds favoritos e escolha os temas. O GeraFeed monitora tudo automaticamente.',
  },
  {
    icon: PenLine,
    title: 'A IA reescreve e aplica SEO',
    desc: 'Filtragem inteligente, reescrita com voz única e otimização de title, meta description e keywords.',
  },
  {
    icon: ImageIcon,
    title: 'Imagens originais anti-plágio',
    desc: 'O sistema processa as imagens para evitar duplicidade e proteger a autoridade do seu domínio.',
  },
  {
    icon: UploadCloud,
    title: 'Aprove com 1 clique',
    desc: 'Revise o artigo pronto e publique direto no seu WordPress via REST API. Simples assim.',
  },
]

export function HowItWorks() {
  return (
    <section id="como-funciona" className="scroll-mt-20 border-b border-border py-20 lg:py-28">
      <div className="mx-auto max-w-6xl px-4 sm:px-6">
        <Reveal className="mx-auto max-w-2xl text-center">
          <span className="text-sm font-bold uppercase tracking-wider text-primary">Como Funciona</span>
          <h2 className="mt-3 text-balance font-display text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
            Do feed ao WordPress em quatro passos simples
          </h2>
          <p className="mt-4 text-pretty text-lg text-muted-foreground">
            Você configura uma vez e o conteúdo passa a fluir sozinho — com você no controle da aprovação.
          </p>
        </Reveal>

        <ol className="mt-14 grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          {steps.map((step, i) => (
            <Reveal as="li" key={step.title} delay={i} className="relative rounded-2xl border border-border bg-card p-6">
              <span className="font-display text-sm font-bold text-cta">
                {String(i + 1).padStart(2, '0')}
              </span>
              <span className="mt-4 flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10 text-primary">
                <step.icon className="h-6 w-6" aria-hidden="true" />
              </span>
              <h3 className="mt-4 font-display text-lg font-bold text-foreground">{step.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{step.desc}</p>
            </Reveal>
          ))}
        </ol>
      </div>
    </section>
  )
}
