'use client'

import { Check } from 'lucide-react'
import { Reveal } from './reveal'

const plans = [
  {
    name: 'Starter',
    price: 'Grátis',
    period: '',
    description: 'Para testar e começar sem custo.',
    features: [
      'Até 10 artigos por mês',
      '1 site WordPress',
      'Bring Your Own Key (API própria obrigatória)',
      'Coleta de RSS',
      'Reescrita com IA',
    ],
    cta: 'Comece Grátis',
    highlight: false,
  },
  {
    name: 'Creator',
    price: 'R$ 67',
    period: '/mês',
    description: 'Para criadores que querem consistência.',
    features: [
      'Até 150 artigos por mês',
      '3 sites WordPress',
      'IA inclusa (sem API própria)',
      'Imagens processadas anti-plágio',
      'SEO automático completo',
      'Atribuição automática de fonte',
    ],
    cta: 'Assinar o Creator',
    highlight: true,
    badge: 'Mais Escolhido',
  },
  {
    name: 'Scale',
    price: 'R$ 197',
    period: '/mês',
    description: 'Para agências e operações em volume.',
    features: [
      'Até 800 artigos por mês',
      '10 sites WordPress',
      'Auto-Publishing automático',
      'IA inclusa (sem API própria)',
      'Imagens anti-plágio',
      'Suporte prioritário',
    ],
    cta: 'Assinar o Scale',
    highlight: false,
  },
]

export function Pricing() {
  return (
    <section id="precos" className="scroll-mt-20 border-b border-border bg-secondary/40 py-20 lg:py-28">
      <div className="mx-auto max-w-6xl px-4 sm:px-6">
        <Reveal className="mx-auto max-w-2xl text-center">
          <span className="text-sm font-bold uppercase tracking-wider text-primary">Preços</span>
          <h2 className="mt-3 text-balance font-display text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
            Planos que crescem junto com o seu conteúdo
          </h2>
          <p className="mt-4 text-pretty text-lg text-muted-foreground">
            Comece grátis com a sua própria chave de IA. Faça upgrade quando quiser escalar.
          </p>
        </Reveal>

        <div className="mt-14 grid items-start gap-6 lg:grid-cols-3">
          {plans.map((plan, i) => (
            <Reveal
              key={plan.name}
              delay={i}
              className={
                plan.highlight
                  ? 'relative rounded-2xl border-2 border-primary bg-card p-8 shadow-xl shadow-primary/10 lg:-translate-y-4'
                  : 'relative rounded-2xl border border-border bg-card p-8'
              }
            >
              {plan.badge && (
                <span className="absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-cta px-4 py-1 text-xs font-bold text-cta-foreground shadow-sm">
                  {plan.badge}
                </span>
              )}
              <h3 className="font-display text-xl font-bold text-foreground">{plan.name}</h3>
              <p className="mt-1 text-sm text-muted-foreground">{plan.description}</p>
              <div className="mt-5 flex items-baseline gap-1">
                <span className="font-display text-4xl font-extrabold text-foreground">{plan.price}</span>
                <span className="text-sm font-medium text-muted-foreground">{plan.period}</span>
              </div>

              <a
                href="#"
                className={
                  plan.highlight
                    ? 'mt-6 block rounded-xl bg-cta px-5 py-3 text-center text-sm font-bold text-cta-foreground shadow-sm shadow-cta/30 transition-transform hover:-translate-y-0.5'
                    : 'mt-6 block rounded-xl border border-border bg-secondary px-5 py-3 text-center text-sm font-semibold text-foreground transition-colors hover:bg-accent'
                }
              >
                {plan.cta}
              </a>

              <ul className="mt-7 space-y-3">
                {plan.features.map((f) => (
                  <li key={f} className="flex items-start gap-3 text-sm text-foreground">
                    <Check className="mt-0.5 h-4 w-4 shrink-0 text-cta" aria-hidden="true" />
                    {f}
                  </li>
                ))}
              </ul>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  )
}
